<?php include('layouts/header.php'); ?>

<h2>Welcome to Your Admin Dashboard</h2>


<?php include('layouts/footer.php'); ?>
