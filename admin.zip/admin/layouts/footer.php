</main>

<footer style="text-align: center; padding: 20px; margin-top: 40px;">
    &copy; <?= date('Y') ?> Ibrahim Denis Fofanah. All Rights Reserved.
</footer>

</body>
</html>
